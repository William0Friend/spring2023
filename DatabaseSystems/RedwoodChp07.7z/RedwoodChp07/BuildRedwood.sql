-----------------------------------------------------------
--Search and Replace All as follows:
-- 1) Replace <DB> with the name of the database to create.
-- 2) Replace <PATH> with the full path to this file and 
--    others associated with it. Ensure it ends with a 
--    backslash. E.g., C:\MyDatabases\
-----------------------------------------------------------
--
IF NOT EXISTS(SELECT * FROM sys.databases
          WHERE name = N'<DB>')
	CREATE DATABASE <DB>
GO
USE <DB>
--
-- Alter the path so the script can find the CSV files
--
DECLARE
   @data_path nvarchar(256);
SELECT @data_path = '<PATH>';
--
--GO
-- =======================================
-- Delete existing tables
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'CustAgentList'
         )
  DROP TABLE CustAgentList;
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'Listings'
         )
  DROP TABLE Listings;
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'Properties'
         )
  DROP TABLE Properties;
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'Agents'
         )
  DROP TABLE Agents;
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'Customers'
         )
  DROP TABLE Customers;
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'ContactReason'
         )
  DROP TABLE ContactReason;
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'SaleStatus'
         )
  DROP TABLE SaleStatus;
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'LicenseStatus'
         )
  DROP TABLE LicenseStatus;
--
IF EXISTS(
  SELECT *
  FROM sys.tables
  WHERE name = N'AgentsHR'
         )
  DROP TABLE AgentsHR;
--
--
-- Create tables
--
CREATE TABLE LicenseStatus
     (LicenseStatusID INT           NOT NULL,
      StatusText      NVARCHAR(25),
      CONSTRAINT pk_licensestatus PRIMARY KEY (LicenseStatusID)
     );
--
CREATE TABLE SaleStatus
     (SaleStatusID INT           NOT NULL,
      SaleStatus   NVARCHAR(10),
      CONSTRAINT pk_salestatus PRIMARY KEY (SaleStatusID)
     );
--
CREATE TABLE ContactReason
     (ContactReason   NVARCHAR(15)    NOT NULL,
      Description     NVARCHAR(50),
      CONSTRAINT pk_ContactReason PRIMARY KEY (ContactReason)
     );
--
CREATE TABLE Customers
     (CustomerID INT         NOT NULL,
      FirstName  NVARCHAR(30) NOT NULL,
      LastName   NVARCHAR(30) NOT NULL,
      Address    NVARCHAR(40),
      City       NVARCHAR(30),
      State      NVARCHAR(20),
      Zipcode    NVARCHAR(20),
      HomePhone  NVARCHAR(20),
      CellPhone  NVARCHAR(20),
      WorkPhone  NVARCHAR(20),
      CONSTRAINT pk_customers PRIMARY KEY (CustomerID)
     );
--
CREATE TABLE Agents
     (AgentID         INT           NOT NULL,
      FirstName       NVARCHAR(30),
      LastName        NVARCHAR(30),
      HireDate        DATETIME,
      BirthDate       DATETIME,
      Gender          NVARCHAR(10),
      WorkPhone       NVARCHAR(20),
      CellPhone       NVARCHAR(20),
      HomePhone       NVARCHAR(20),
      Title           NVARCHAR(20),
      TaxID           NVARCHAR(20),
      LicenseID       NVARCHAR(20),
      LicenseDate     DATETIME,
      LicenseExpire   DATETIME,
      LicenseStatusID INT,
      CONSTRAINT pk_Agents PRIMARY KEY (AgentID),
      CONSTRAINT fk_Agents_License FOREIGN KEY (LicenseStatusID)
         REFERENCES LicenseStatus(LicenseStatusID)
         ON DELETE CASCADE
     )
--
CREATE TABLE Properties
     (PropertyID INT          NOT NULL,
      OwnerID    INT          NOT NULL,
      Address    NVARCHAR(30) NOT NULL,
      City       NVARChAR(30) NOT NULL,
      State      NVARCHAR(20),
      Zipcode    NVARCHAR(20),
      Bedrooms   INT,
      Bathrooms  INT,
      Stories    INT,
      SqFt       INT,
      YearBuilt  NUMERIC(4),
      Zone       NVARCHAR(4),
      LotSize    NUMERIC(4,2),
      Latitude   NUMERIC(8,5),
      Longitude  NUMERIC(8,5),
      CONSTRAINT pk_properties PRIMARY KEY (PropertyID),
      CONSTRAINT fk_Properties_Customers FOREIGN KEY (OwnerID)
         REFERENCES Customers (CustomerID)
         ON DELETE CASCADE
     );
--
CREATE TABLE Listings
     (ListingID      INT NOT NULL,
      PropertyID     INT NOT NULL,
      ListingAgentID INT NOT NULL,
      SaleStatusID   INT,
      BeginListDate  DATETIME,
      EndListDate    DATETIME,
      AskingPrice    MONEY,
      HousePhoto     IMAGE,
      CONSTRAINT pk_listings PRIMARY KEY (ListingID),
      CONSTRAINT fk_Listings_Properties FOREIGN KEY (PropertyID)
         REFERENCES Properties (PropertyID)
         ON DELETE CASCADE,
      CONSTRAINT fk_Listings_Agents FOREIGN KEY (ListingAgentID)
         REFERENCES Agents (AgentID)
         ON DELETE CASCADE,
      CONSTRAINT fk_Listings_SaleStatus FOREIGN KEY (SaleStatusID)
         REFERENCES SaleStatus (SaleStatusID)
         ON DELETE CASCADE
     );
--
CREATE TABLE CustAgentList
     (CustomerID     INT NOT NULL,
      AgentID        INT NOT NULL,
      ListingID      INT NOT NULL,
      ContactDate    DATETIME    NOT NULL,
      ContactReason  NVARCHAR(15),
      BidPrice       MONEY,
      CommissionRate NUMERIC(4,4),
      CONSTRAINT pk_CustAgentList PRIMARY KEY (CustomerID, AgentID, ListingID, ContactDate),
      CONSTRAINT fk_CustAgentList_Cust FOREIGN KEY (CustomerID)
         REFERENCES Customers (CustomerID)
         ON DELETE CASCADE,
      CONSTRAINT fk_CustAgentList_Agent FOREIGN KEY (AgentID)
         REFERENCES Agents (AgentID)
         ON DELETE CASCADE,
--      CONSTRAINT fk_CustAgentList_Listing FOREIGN KEY (ListingID)
--         REFERENCES Listings (ListingID)
--         ON DELETE CASCADE,
      CONSTRAINT fk_CustAgentList_Contact FOREIGN KEY (ContactReason)
         REFERENCES ContactReason (ContactReason)
         ON DELETE CASCADE
     );
--
CREATE TABLE AgentsHR
     (AgentID    INT PRIMARY KEY,
      Dependents INT,
      BaseSalary INT,
      Marital    NVARCHAR(1),
      SSN        NVARCHAR(11),
      Ethnicity  INT,
      Vacation   INT,
      Team       INT,
     );
--
-- Load table data
--
-- Table 1 LicenseStatus
--
EXECUTE (N'BULK INSERT LicenseStatus FROM ''' + @data_path + N'LicenseStatus.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
--
-- Table 2 SaleStatus
--
EXECUTE (N'BULK INSERT SaleStatus FROM ''' + @data_path + N'SaleStatus.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
--
-- Table 3 ContactReason
--
EXECUTE (N'BULK INSERT ContactReason FROM ''' + @data_path + N'ContactReason.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
--
-- Table 4 Customers
--
EXECUTE (N'BULK INSERT Customers FROM ''' + @data_path + N'Customers.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
--
-- Table 5 Agents
--
EXECUTE (N'BULK INSERT Agents FROM ''' + @data_path + N'Agents.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
--
-- Table 6 Properties
--
EXECUTE (N'BULK INSERT Properties FROM ''' + @data_path + N'Properties.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
--
-- Table 7 Listings
--
EXECUTE (N'BULK INSERT Listings FROM ''' + @data_path + N'Listings.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
--
--
-- Table 8 CustAgentList
--
EXECUTE (N'BULK INSERT CustAgentList FROM ''' + @data_path + N'CustAgentList.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
--
--
-- Table 9 AgentsHR
--
EXECUTE (N'BULK INSERT AgentsHR FROM ''' + @data_path + N'AgentsHR.csv''
WITH (
    CHECK_CONSTRAINTS,
    CODEPAGE=''ACP'',
    DATAFILETYPE = ''char'',
    FIELDTERMINATOR= '','',
    ROWTERMINATOR = ''\n'',
    KEEPIDENTITY,
    TABLOCK
);');
-- ================================================
-- List table names and row counts for confirmation
--
GO
SET NOCOUNT ON
SELECT 'LicenseStatus' "Table", COUNT(*) "Rows" FROM LicenseStatus     UNION
SELECT 'SaleStatus',            COUNT(*)  FROM SaleStatus              UNION
SELECT 'ContactReason',         COUNT(*)  FROM ContactReason           UNION
SELECT 'Customers',             COUNT(*)  FROM Customers               UNION
SELECT 'Agents',                COUNT(*)  FROM Agents                  UNION
SELECT 'Properties',            COUNT(*)  FROM Properties              UNION
SELECT 'Listings',              COUNT(*)  FROM Listings                UNION
SELECT 'CustAgentList',         COUNT(*)  FROM CustAgentList           UNION
SELECT 'AgentsHR',              COUNT(*)  FROM AgentsHR
ORDER BY 1;
SET NOCOUNT OFF
GO
