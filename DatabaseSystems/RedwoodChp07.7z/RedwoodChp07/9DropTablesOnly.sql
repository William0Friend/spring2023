USE Redwood
GO
DROP TABLE Agents;
DROP TABLE AgentsHR;
DROP TABLE ContactReason;
DROP TABLE CustAgentList;
DROP TABLE Customers;
DROP TABLE LicenseStatus;
DROP TABLE Listings;
DROP TABLE Properties;
DROP TABLE SaleStatus;
GO