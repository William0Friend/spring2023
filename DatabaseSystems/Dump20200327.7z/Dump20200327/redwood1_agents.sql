-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: redwood1
-- ------------------------------------------------------
-- Server version	8.0.19

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `agents`
--

DROP TABLE IF EXISTS `agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agents` (
  `AgentID` int NOT NULL,
  `FirstName` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `LastName` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `HireDate` varchar(120) DEFAULT NULL,
  `Birthdate` varchar(120) DEFAULT NULL,
  `Gender` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `WorkPhone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `CellPhone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `HomePhone` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Title` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `TaxID` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `LicenseID` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `LicenseDate` varchar(120) DEFAULT NULL,
  `LicenseExpire` varchar(120) DEFAULT NULL,
  `LicenseStatusID` int DEFAULT NULL,
  PRIMARY KEY (`AgentID`),
  KEY `fk_Agents_License` (`LicenseStatusID`),
  CONSTRAINT `fk_Agents_License` FOREIGN KEY (`LicenseStatusID`) REFERENCES `licensestatus` (`LicenseStatusID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agents`
--

LOCK TABLES `agents` WRITE;
/*!40000 ALTER TABLE `agents` DISABLE KEYS */;
INSERT INTO `agents` VALUES (10041,'Kai','Marcoux','03-Oct-96','12-Dec-70','M','(707) 555-0361','(707) 555-5313','(707) 555-7185','Salesperson','868-26-8646','107157413','30-Jan-97','01-Feb-00',1001),(10235,'Tobias','Carling','19-Dec-00','19-Oct-75','M','(707) 555-1983','(707) 555-5662','(707) 555-0930','Salesperson','988-80-3528','110315480','24-May-01','01-Jun-04',1002),(10429,'Elizabeth','Dahlen','23-May-05','03-Oct-69','F','(707) 555-7218','(707) 555-1512','(707) 555-6112','Salesperson','775-29-1524','107449992','22-Dec-04','01-Jan-08',1001),(10497,'Ramanathan','Rowe','05-Sep-97','23-Oct-53','M','(707) 555-9839','(707) 555-0614','(707) 555-7843','Salesperson','796-78-6888','105702043','06-Apr-99','01-May-02',1001),(10849,'Heather','Sheibani','18-Jul-03','03-Mar-83','F','(707) 555-5635','(707) 555-7185','(707) 555-7241','Salesperson','844-62-2216','103297406','27-Nov-02','01-Dec-05',1001),(10913,'Bruce','Voss','05-Jun-96','03-Apr-70','M','(707) 555-8389','(707) 555-5865','(707) 555-9413','Salesperson','823-14-2747','103801192','27-Aug-95','01-Sep-98',1001),(11775,'Cecilia','Romero','01-Nov-99','21-Oct-62','F','(707) 555-2430','(707) 555-1381','(707) 555-8178','Salesperson','917-82-1997','101805003','02-May-99','01-Jun-02',1001),(12211,'Cornelis','Dann','02-Sep-01','16-Jul-59','M','(707) 555-9652','(707) 555-4991','(707) 555-8797','Salesperson','880-50-5551','106259004','10-Sep-00','01-Oct-03',1001),(12301,'Danial','Silverburg','21-Sep-97','11-Jan-59','M','(707) 555-5865','(707) 555-6210','(707) 555-9180','Salesperson','824-61-3146','109085617','24-Oct-98','01-Nov-01',1001),(12499,'Clair','Robinson','16-Oct-06','01-Jul-69','F','(707) 555-1950','(707) 555-9068','(707) 555-3599','Salesperson','957-90-3925','104722164','29-Mar-06','01-Apr-09',1001),(12715,'Nancy','Piperova','24-Dec-02','21-Jun-78','F','(707) 555-0492','(707) 555-0639','(707) 555-4769','Salesperson','988-84-1259','100652309','27-May-02','01-Jun-05',1001),(12765,'Edwin','Townsend','12-Sep-06','01-Feb-55','M','(707) 555-9485','(707) 555-8096','(707) 555-5080','Salesperson','995-49-8511','107332564','26-Mar-06','01-Apr-09',1001),(12875,'Essi','Okindo','20-Dec-95','04-Mar-74','M','(707) 555-0719','(707) 555-7851','(707) 555-8575','Broker','959-20-1421','109251209','26-Apr-96','01-May-99',1001),(12963,'Lee','Reed','18-Sep-00','25-Mar-56','F','(707) 555-7213','(707) 555-7842','(707) 555-9458','Salesperson','857-64-8183','105028355','20-Feb-00','01-Mar-03',1001),(13353,'Stanislaw','Soltwedel','04-May-96','04-Apr-69','M','(707) 555-0089','(707) 555-6453','(707) 555-5640','Salesperson','960-51-6734','106419907','04-May-97','01-Jun-00',1001),(13555,'Belinda','Chong','30-Aug-95','20-Oct-57','F','(707) 555-0962','(707) 555-2060','(707) 555-9982','Salesperson','922-26-8422','104560696','22-Jan-97','01-Feb-00',1001),(13649,'Ricki','Selby','05-Jan-02','08-May-80','F','(707) 555-3933','(707) 555-6025','(707) 555-2063','Broker','988-73-1635','103277328','23-Dec-01','01-Jan-05',1001),(13771,'Jessica','Taylor','29-Jun-98','26-Sep-61','F','(707) 555-4529','(707) 555-3011','(707) 555-1482','Broker','791-13-5193','110887157','23-Oct-99','01-Nov-02',1001),(14117,'Tim','St-Onge','13-Jul-97','19-May-68','M','(707) 555-4697','(707) 555-6623','(707) 555-3395','Salesperson','876-74-5003','107695632','25-Jun-98','01-Jul-01',1001),(14447,'Jackson','Flamenbaum','08-Feb-00','03-May-68','M','(707) 555-5551','(707) 555-9192','(707) 555-5460','Salesperson','884-95-4008','108305698','16-Feb-99','01-Mar-02',1001),(14599,'Barbara','Herring','07-Dec-03','04-Feb-65','F','(707) 555-3355','(707) 555-3887','(707) 555-2602','Salesperson','887-70-6142','101565046','10-Sep-02','01-Oct-05',1001),(14601,'Sindisiwe','Weber','25-Aug-06','21-Dec-60','M','(707) 555-0616','(707) 555-3058','(707) 555-9458','Salesperson','879-39-7737','105924070','21-Feb-07','01-Mar-10',1007),(14677,'James','Kellogg','05-Feb-02','02-Nov-69','M','(707) 555-2075','(707) 555-0058','(707) 555-3883','Salesperson','864-96-6542','109907391','06-Jun-01','01-Jul-04',1001),(14883,'Crystal','Fernandez','30-May-97','29-Nov-64','F','(707) 555-1652','(707) 555-0712','(707) 555-5553','Salesperson','929-32-2337','106164454','26-Jul-96','01-Aug-99',1001),(15061,'Christine','Williams','08-Jan-96','16-Aug-67','F','(707) 555-5525','(707) 555-1339','(707) 555-5311','Salesperson','907-52-1430','110428647','03-Aug-97','01-Sep-00',1001),(15233,'David','Gagnon','17-Jan-99','06-Nov-58','M','(707) 555-8668','(707) 555-3390','(707) 555-0675','Broker','917-17-7620','104570643','14-Mar-00','01-Apr-03',1001),(15293,'Lora','Allee','14-Jul-96','13-May-59','F','(707) 555-9990','(707) 555-4690','(707) 555-0932','Broker','887-67-7281','110309167','22-Nov-95','01-Dec-98',1001),(15349,'Tim','Schutz','21-Jun-04','21-Aug-83','M','(707) 555-6005','(707) 555-9930','(707) 555-3760','Salesperson','843-24-5404','107803586','17-Mar-03','01-Apr-06',1001),(15521,'Patricia','Lewis','30-May-06','10-Apr-59','F','(707) 555-8690','(707) 555-0023','(707) 555-3148','Broker','982-80-5911','105939224','29-Jun-07','01-Jul-10',1001);
/*!40000 ALTER TABLE `agents` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-27 19:26:07
